import json

inst = json.load(open('instances_default.json'))

d = {}
for im in inst['images']:
    filename = im['file_name']
    d[filename] = {
        "fileref": "",
        "size": im['width'] * im['height'],
        "filename": filename,
        "base64_img_data": "",
        "file_attributes": {},
        "regions": {}
    }
    i = 0
    for reg in inst['annotations']:
        if reg['image_id'] == im['id']:
            d[filename]['regions'][i] = {
                "shape_attributes": {
                    "name": "polygon",
                    "all_points_x": [i*0.75 for i in reg['segmentation'][0][0::2]],
                    "all_points_y": [i*0.75 for i in reg['segmentation'][0][1::2]]
                },
                "region_attributes": {}
            }
            i+=1

with open('via_region_data_plants.json', 'w') as file:
    json.dump(d, file)